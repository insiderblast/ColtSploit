#ColtSploit regroup the mostly cyberattack methods used nowadays by most Hacker
#My tool regroup the pre-compiled attack such as:
   •port scanner
   •Denial of Service
   •MAC spoofing
   •ARP poisoning
   •sniffing
#Use only it for penetration
#Don't be evil
#For Educationnal purposes
#Coded by The Dutchman attacker
!Enjoy Coding